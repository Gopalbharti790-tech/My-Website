from django.urls import path
from . import views

urlpatterns=[
    path("", views.homepage, name='home'),
    path("allposts/",views.blogposts, name='allpost'),
    
    path("allposts/<slug:blog>",views.blog_posts,name='blog-post')
]